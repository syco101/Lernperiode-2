using System.Data;
using WinFormsApp_Wortschatzquiz_Projekt;

namespace WinFormsApp_Wortschatzquiz_Projekt
{
    public partial class Form1 : Form
    {



        private static async Task Savefile(string requestUrl, string localFilePath)  // datenbank zugriff
        {
            var httpClient = new HttpClient();

            var httpResult = await httpClient.GetAsync(requestUrl);
            using var resultStream = await httpResult.Content.ReadAsStreamAsync();
            using var fileStream = File.Create(localFilePath);
            resultStream.CopyTo(fileStream);

        }
        public Form1() // initialisierung der kn�pfe
        {
            InitializeComponent();


        }

        private void Schwierigkeitsstufen(object sender, EventArgs e) //schwierigkeitsstufe label
        {

        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e) // initialisierung der kn�pfe
        {

        }

        private void button1_click(object sender, EventArgs e) // einfach
        {

            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();

        }

        private void button2_click(object sender, EventArgs e) // fortgeschritten
        {

            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();

        }
        private void button3_click(object sender, EventArgs e) // schwer
        {

            Form4 form4 = new Form4();
            form4.Show();
            this.Hide();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
