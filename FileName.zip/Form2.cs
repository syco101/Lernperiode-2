﻿using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp_Wortschatzquiz_Projekt
{
    public partial class Form2 : Form
    {
        private string[] RandomWörter;
        private Random zufallsgenerator;
        private string[] myboxes;

        public Form2()
        {
            InitializeComponent();
            CheckBox[] myboxes = { checkBox1, checkBox2, checkBox3, checkBox4 };

            button3.Click += button3_Click;

            RandomWörter = new string[] { "Auto", "Flugzeug", "Person", "Betrug", "Zauberer", "riesig", "laufen", "mögen", "suchen", "erfahren",
            "Land", "schön", "schnell", "langsam", "Herkunft", "nervig", "müde", "sagen", "groß", "Genesung", "Stand", "Sprache", "rennen", "Edelstein",
            "Party","Teil","Lust","Leid","eklig","Freund" };

            zufallsgenerator = new Random();



            ShowRandomWord();
        }


        private void ShowRandomWord()
        {
            int zufallsIndex = zufallsgenerator.Next(0, RandomWörter.Length);
            string questionWord = RandomWörter[zufallsIndex];
            label1.Text = questionWord;

            string falschVersion = questionWord + "falsch";
            bool hasFalschVersion = Array.Exists(RandomWörter, word => word == falschVersion);

            string[] synonyms;

            if (hasFalschVersion)
            {
                synonyms = GetCorrectSynonyms(falschVersion);
            }
            else
            {
                synonyms = GetCorrectSynonyms(questionWord);
            }

            if (synonyms.Length >= 4)
            {
                checkBox1.Text = synonyms[0];
                checkBox2.Text = synonyms[1];
                checkBox3.Text = synonyms[2];
                checkBox4.Text = synonyms[3];
            }          
        }

        private void CheckSelectedSynonyms(string[] selectedSynonyms)
            {

                string randomWord = label1.Text;

            
                string[] correctSynonyms = GetCorrectSynonyms(randomWord);


                if (AreArraysEqual(selectedSynonyms, correctSynonyms))
                {
                    MessageBox.Show("Richtig! Die ausgewählten Synonyme sind korrekt.");
                }
                else
                {
                    MessageBox.Show($"Leider falsch. Die richtigen Synonyme sind: {string.Join(", ", correctSynonyms)}");
                }

                // Zeige das nächste zufällige Wort an
                ShowRandomWord();
            }
            private string[] GetCorrectSynonyms(string word)
            {
                bool isFalschVersion = word.EndsWith("falsch");


                if (isFalschVersion)
                {
                    word = word.Substring(0, word.Length - 6); // Updated zu entferne "falsch"
                }
                switch (word)
                {
                    case "Auto":
                        return isFalschVersion ? new string[] { "LKW", "Laster", "Schubwagen", "Seifenkiste" } : new string[] { "Fahrzeug", "Kraftwagen", "PKW", "Vehikel" };
                    case "Flugzeug":
                        return isFalschVersion ? new string[] { " " } : new string[] { "Luftfahrzeug", "Flieger", "Aeroplane" };
                //  case "Autofalsch":
                //    return new string[] { "LKW","Laster","Schubwagen","Seifenkiste" };                  
                //case "Flugzeug":
                // return new string[] { "Luftfahrzeug", "Flieger", "Aeroplane", "Flugapperate" };
                // case "Flugzeugfalsch":
                //return new string[] { "Bodenfahrzeug", "Nichtflieger", "Läufer", "Propellermaschine" };                                
                case "Person":
                    return new string[] { "Partie", "Rolle", "Part", "Mensch" };
                case "Personfalsch":
                    return new string[] { "Unmensch ", "Tier", "Ding", "Kreatur" };
                case "Betrug":
                    return new string[] { "Täuschung", "Beschiss", "Schummelei", "Schwindel" };
                case "Bertrugfalsch":
                    return new string[] { "Ehrlichkeit ", "Transparenz", "Fairness", "Aufrichtigkeit" };
                case "Zauberer":
                    return new string[] { "Beschwörer", "Hexenmeister", "Magier", "Schwarzkünstler" };
                case "Zaubererfalsch":
                    return new string[] { "Mogel ", "Laie", "Realist", "Normalbürger" };
                case "riesig":
                    return new string[] { "enorm", "gewaltig", "gross", "imposant" };
                case "riesigfalsch":
                    return new string[] { "Winzig ", "klein", "bescheiden", "mini" };
                case "laufen":
                    return new string[] { "rasen", "düsen", "flitzen", "sausen" };
                case "laufenfalsch":
                    return new string[] { "Sich Zeit nehmen ", "stehen", "verharren", "Beweglichkeit" };
                case "mögen":
                    return new string[] { "gernhaben", "leiden", "geniessen", "dessen Kompanie geniessen" };
                case "mögenfalsch":
                    return new string[] { "hassen ", "verabscheuen", "Ablehnen", "Abneigen" };
                case "suchen":
                    return new string[] { "ausforschen", "recherchieren", "nachschlagen", "ausspähen" };
                case "suchenfalsch":
                    return new string[] { "verbergen ", "sich auf dem Weg machen", "verstecken", "Trist" };
                case "erfahren":
                    return new string[] { "Bescheid bekommen", "in Kenntnis gestzt werden", "informiert werden", "etwas Heraus finden" };
                case "erfahrenfalsch":
                    return new string[] { "ignorieren ", "unwissend bleiben", "nicht mitbekommen", "nicht zuhören" };
                case "Land":
                    return new string[] { "Boden", "Grund", "Nation", "Nationalstaat" };
                case "Landfalsch":
                    return new string[] { "Luft ", "Weltraum", "Niemandsland", "Insel" };
                case "schön":
                    return new string[] { "attraktiv", "hübsch", "ansehnlich", "hinreissend" };
                case "schönfalsch":
                    return new string[] { "grob ", "hässlich", "hinreissend", "Trist" };
                case "schnell":
                    return new string[] { "eilig", "flink", "flott", "rapid" };
                case "schnellfalsch":
                    return new string[] { "gebremst", "dösig", "hinreissend", "fegen" };
                case "langsam":
                    return new string[] { "denkfaul", "begriffsstutzig", "stumpfsinnig", "dösig", };
                case "langsamfalsch":
                    return new string[] { "grob", "hässlich", "Abneigen", "nachschlagen" };
                case "Herkunft":
                    return new string[] { "Abstammung", "Elternhaus", "Ursprung", "Abkunft" };
                case "Herkunftfalsch":
                    return new string[] { "Ziel ", "Herkunft", "Abstammung", "Geburtsort" };
                case "nervig":
                    return new string[] { "anstrengend", "lästig", "leidig", "störend" };
                case "nervigfalsch":
                    return new string[] { "Angenehm ", "Auffalend", "Anstrengend", "Beruhigend" };
                case "müde":
                    return new string[] { "hundemüde", "reif für das Bett", "erschöpft", "energielos" };
                case "müdefalsch":
                    return new string[] { "wach", "anwesend", "teilweise da", "energetisiert" };
                case "sagen":
                    return new string[] { "reden", "sprechen", "kommunizieren", "sich äussern" };
                case "sagenfalsch":
                    return new string[] { "schweigen", "zuhören", "beobachten", "ansehen" };
                case "gross":
                    return new string[] { "bedeutsam", "enorm", "gigantisch", "mächtig" };
                case "grossfalsch":
                    return new string[] { "winzig", "nicht gewachsen", "Zwerg", "klein" };
                case "Genesung":
                    return new string[] { "erholung", "Gesundung", "Heilung", "Rekonvaleszenz" };
                case "Genesungfalsch":
                    return new string[] { "erkrankung", "schlechter Zustand", "Verschlechterung", "Rückgang" };
                case "Stand":
                    return new string[] { "Bevölkerungsschicht", "Gesellschaftsschicht", "Klasse", "Schicht" };
                case "Standfalsch":
                    return new string[] { "Veränderung", "Bewegung", "Bestimmung", "Mobilität" };
                case "Sprache":
                    return new string[] { "Ausdrucksform", "Sprechvermögen", "Zunge", "Sprachgebrauch" };
                case "Sprachefalsch":
                    return new string[] { "schweigen ", "Stumm", "ansehen", "störend" };
                case "rennen":
                    return new string[] { "sprinten", "eilen", "flitzen", "stürmen" };
                case "rennenfalsch":
                    return new string[] { "fegen", "gigantisch", "Anstrengend", "rapid" };
                case "Edelstein":
                    return new string[] { "Juwel", "Klunker", "Schmuckstein", "Brocken" };
                case "Edelsteinfalsch":
                    return new string[] { "erschöpft", "schlechter Zustand", "erschöpft", "Angenehm " };
                case "Party":
                    return new string[] { "Anlass", "Feier", "Fest", "Fete" };
                case "Partyfalsch":
                    return new string[] { "Nation", "enorm", "dösig", "Gesundung", };
                case "Teil":
                    return new string[] { "Bestandteil", "Element", "Stück", "Komponente" };
                case "Teilfalsch":
                    return new string[] { "Genosse", "Anlass", "Bestimmung", "Klasse", };
                case "Lust":
                    return new string[] { "Sehen", "Verlangen", "Tendenz", "Begierde" };
                case "Lustfalsch":
                    return new string[] { "abscheulich", "beobachten", "leidig", "Weltraum" };
                case "Leid":
                    return new string[] { "Elend", "Plage", "Qual", "Folter" };
                case "Leidfalsch":
                    return new string[] { "Grässlich", "Fest", "Tendenz", "Mobilität" };
                case "eklig":
                    return new string[] { "widerlich", "abscheulich", "abstossend", "Grässlich" };
                case "ekligfalsch":
                    return new string[] { "angenehm ", "Lecker", "Zunge", "Anlass" };
                case "Freund":
                    return new string[] { "Genosse", "Kumpel", "kamerad", "Kollege" };
                case "Freundfalsch":
                    return new string[] { "Brocken", "Sehen", "Qual", "Brocken" };
                default:
                    return new string[] { }; // wenn keine passenden Synonyme gefunden werden
            }
        }

        private bool AreArraysEqual(string[] array1, string[] array2)
        {
            int minLength = Math.Min(array1.Length, array2.Length);

            for (int i = 0; i < minLength; i++)
            {
                if (array1[i] != array2[i])
                {
                    return false;
                }
            }
            return array1.Length == array2.Length;
        }


        private static async Task Savefile(string requestUrl, string localFilePath)
        {
            var httpClient = new HttpClient();

            var httpResult = await httpClient.GetAsync(requestUrl);
            using var resultStream = await httpResult.Content.ReadAsStreamAsync();
            using var fileStream = File.Create(localFilePath);
            resultStream.CopyTo(fileStream);
        }

        private void Form2_Load(object sender, EventArgs e) // ?
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();    
        }
        private void label1_Click(object sender, EventArgs e) // random Wörter
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e) // Redundanz
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {


        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            int richtigfalsch = zufallsgenerator.Next(1, 3);
            if (richtigfalsch == 1)
            {


            }
            else
            {

            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            int richtigfalsch = zufallsgenerator.Next(1, 3);
            if (richtigfalsch == 1)
            {
                ///  checkBox.Text = 

            }
            else
            {

            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            int richtigfalsch = zufallsgenerator.Next(1, 3);
            if (richtigfalsch == 1)
            {


            }
            else
            {

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {


        }

        private void button3_Click(object sender, EventArgs e) //antwort angeben
        {
            
            checkBox1.Enabled = checkBox2.Enabled = checkBox3.Enabled = checkBox4.Enabled = false;

            string currentWord = label1.Text;

            string[] correctSynonyms = GetCorrectSynonyms(currentWord);

            if (correctSynonyms.Length >= 0)
            {
                string correctAnswers = "Richtige Antworten: " + string.Join(", " , correctSynonyms);
                string selectedanwsers = "Deine Auswahl: " + (checkBox1.Checked ? checkBox1.Text + "" : "") +
                    (checkBox2.Checked ? checkBox2.Text + "" : "") +
                    (checkBox3.Checked ? checkBox3.Text + "" : "") +
                    (checkBox4.Checked ? checkBox4.Text + "" : "");

                label3.Text = correctAnswers + Environment.NewLine + selectedanwsers;
            }
            else

            {
                label3.Text = "Wörter nicht vorhanden";
            }

            
            checkBox1.Checked = checkBox2.Checked = checkBox3.Checked = checkBox4.Checked = false;

            
            checkBox1.Enabled = checkBox2.Enabled = checkBox3.Enabled = checkBox4.Enabled = true;

            ShowRandomWord();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e) //stellt Antworten dar
        {
            
        }
    }
}