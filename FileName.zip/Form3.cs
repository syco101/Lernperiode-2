﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp_Wortschatzquiz_Projekt
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            string link = "https://www.openthesaurus.de/synonyme/search?q=";
            string link2 = "&format=text/xml&similar=true";

            Random zufallsgenerator = new Random();






            string[] Wörter;
            Wörter = new string[25];
            Wörter = new string[] { "Auto", "Flugzeug"," Person","Betrug","Zauberer","riesig","laufen","mögen","suchen","erfahren",
            "Land","schön","schnell","langsam","Herkunft","nervig","müde","sagen","groß","Genesung","Stand","Sprache","rennen","Stein","Party"}; // 25 Elemente 

            int zufallsIndex = zufallsgenerator.Next(0, Wörter.Length);
        }
    }
}
